Dragonet Worksheet API readme
1. The API has been desinged using a generic data access framework that scales to most entities
2. The API can also support polyglot persistance, meaning the database configuration without any change in the consumer code
3. The ConnectionString for the Sybase database is given in the web.config file and should be changed accordingly
4. The API can be run by deploying to IIS or by running in Visual Studio under IIS express