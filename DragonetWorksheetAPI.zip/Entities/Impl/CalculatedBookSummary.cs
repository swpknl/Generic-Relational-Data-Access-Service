﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities.Impl
{
    public class CalculatedBookSummary
    {
        public string books { get; set; }
        public string descriptions { get; set; }
        public double breaks { get; set; }
        public double w_reason { get; set; }
        public double matched { get; set; }
        public double position { get; set; }
        public double price { get; set; }
        public double pandl {get;set;}
        public double pv { get; set; }
        public string hugo { get; set; }
    }
}
